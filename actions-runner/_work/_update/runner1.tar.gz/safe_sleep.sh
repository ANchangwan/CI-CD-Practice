#!/bin/bash

SECONDS=0
while [[ $SECONDS -lt $1 ]]; do
    :
done
